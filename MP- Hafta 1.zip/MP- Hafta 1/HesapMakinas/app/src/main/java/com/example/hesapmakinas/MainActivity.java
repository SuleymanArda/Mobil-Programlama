package com.example.hesapmakinas;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private TextView tvDisplay;
    private double firstValue = Double.NaN;
    private double secondValue;
    private char currentOp = '0';
    private boolean isNewOp = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvDisplay = findViewById(R.id.tvDisplay);

        View.OnClickListener numberClickListener = v -> {
            if (isNewOp) {
                tvDisplay.setText("");
                isNewOp = false;
            }
            Button b = (Button) v;
            tvDisplay.append(b.getText().toString());
        };

        findViewById(R.id.btn0).setOnClickListener(numberClickListener);
        findViewById(R.id.btn1).setOnClickListener(numberClickListener);
        findViewById(R.id.btn2).setOnClickListener(numberClickListener);
        findViewById(R.id.btn3).setOnClickListener(numberClickListener);
        findViewById(R.id.btn4).setOnClickListener(numberClickListener);
        findViewById(R.id.btn5).setOnClickListener(numberClickListener);
        findViewById(R.id.btn6).setOnClickListener(numberClickListener);
        findViewById(R.id.btn7).setOnClickListener(numberClickListener);
        findViewById(R.id.btn8).setOnClickListener(numberClickListener);
        findViewById(R.id.btn9).setOnClickListener(numberClickListener);

        View.OnClickListener opClickListener = v -> {
            Button b = (Button) v;
            String op = b.getText().toString();
            String currentText = tvDisplay.getText().toString();
            
            if (currentText.isEmpty() && currentOp == '0') return;

            if (!Double.isNaN(firstValue) && !isNewOp) {
                secondValue = Double.parseDouble(tvDisplay.getText().toString());
                double result = calculate(firstValue, secondValue, currentOp);
                firstValue = result;
                displayResult(result);
            } else if (!currentText.isEmpty()) {
                firstValue = Double.parseDouble(currentText);
            }
            
            currentOp = op.charAt(0);
            isNewOp = true;
        };

        findViewById(R.id.btnAdd).setOnClickListener(opClickListener);
        findViewById(R.id.btnSubtract).setOnClickListener(opClickListener);
        findViewById(R.id.btnMultiply).setOnClickListener(opClickListener);
        findViewById(R.id.btnDivide).setOnClickListener(opClickListener);

        findViewById(R.id.btnEquals).setOnClickListener(v -> {
            if (!Double.isNaN(firstValue) && !isNewOp) {
                secondValue = Double.parseDouble(tvDisplay.getText().toString());
                double result = calculate(firstValue, secondValue, currentOp);
                firstValue = Double.NaN;
                currentOp = '0';
                displayResult(result);
                isNewOp = true;
            }
        });

        findViewById(R.id.btnClear).setOnClickListener(v -> {
            firstValue = Double.NaN;
            secondValue = Double.NaN;
            currentOp = '0';
            tvDisplay.setText("");
            isNewOp = true;
        });
    }

    private double calculate(double val1, double val2, char op) {
        switch (op) {
            case '+': return val1 + val2;
            case '-': return val1 - val2;
            case '*': return val1 * val2;
            case '/': return val2 == 0 ? 0 : val1 / val2;
            default: return val1;
        }
    }

    private void displayResult(double result) {
        if (result == (long) result) {
            tvDisplay.setText(String.valueOf((long) result));
        } else {
            tvDisplay.setText(String.valueOf(result));
        }
    }
}