package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private String[] citiesArray = {
            "Adana", "Adıyaman", "Afyonkarahisar", "Ağrı", "Amasya", "Ankara", "Antalya", "Artvin",
            "Aydın", "Balıkesir", "Bilecik", "Bingöl", "Bitlis", "Bolu", "Burdur", "Bursa",
            "Çanakkale", "Çankırı", "Çorum", "Denizli", "Diyarbakır", "Edirne", "Elazığ", "Erzincan",
            "Erzurum", "Eskişehir", "Gaziantep", "Giresun", "Gümüşhane", "Hakkari", "Hatay", "Isparta",
            "Mersin", "İstanbul", "İzmir", "Kars", "Kastamonu", "Kayseri", "Kırklareli", "Kırşehir",
            "Kocaeli", "Konya", "Kütahya", "Malatya", "Manisa", "Kahramanmaraş", "Mardin", "Muğla",
            "Muş", "Nevşehir", "Niğde", "Ordu", "Rize", "Sakarya", "Samsun", "Siirt",
            "Sinop", "Sivas", "Tekirdağ", "Tokat", "Trabzon", "Tunceli", "Şanlıurfa", "Uşak",
            "Van", "Yozgat", "Zonguldak", "Aksaray", "Bayburt", "Karaman", "Kırıkkale", "Batman",
            "Şırnak", "Bartın", "Ardahan", "Iğdır", "Yalova", "Karabük", "Kilis", "Osmaniye", "Düzce"
    };

    private List<String> cityList = new ArrayList<>();
    private List<Integer> numberList = new ArrayList<>();
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ListView listViewCities = findViewById(R.id.listViewCities);
        ListView listViewNumbers = findViewById(R.id.listViewNumbers);
        Button buttonCheck = findViewById(R.id.buttonCheck);
        TextView textViewResult = findViewById(R.id.textViewResult);

        // Listeleri doldur
        for (String city : citiesArray) {
            cityList.add(city);
        }

        for (int i = 1; i <= 81; i++) {
            numberList.add(i);
        }
        Collections.shuffle(numberList);

        // Adapter'ları ayarla (Görünürlük için)
        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, cityList);
        listViewCities.setAdapter(cityAdapter);

        ArrayAdapter<Integer> numberAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, numberList);
        listViewNumbers.setAdapter(numberAdapter);

        buttonCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Listelerden rastgele seç
                int randomCityIndex = random.nextInt(cityList.size());
                String selectedCity = cityList.get(randomCityIndex);
                
                // Şehir ismine göre orijinal plakasını bul (Dizideki sırası + 1)
                int plateNumber = -1;
                for (int i = 0; i < citiesArray.length; i++) {
                    if (citiesArray[i].equals(selectedCity)) {
                        plateNumber = i + 1;
                        break;
                    }
                }

                int randomNumberIndex = random.nextInt(numberList.size());
                int selectedNumber = numberList.get(randomNumberIndex);

                // Listeleri o öğeye odakla (görsel geri bildirim)
                listViewCities.smoothScrollToPosition(randomCityIndex);
                listViewNumbers.smoothScrollToPosition(randomNumberIndex);

                if (plateNumber != selectedNumber) {
                    textViewResult.setText(selectedCity + " (Plaka: " + plateNumber + ") ile " + selectedNumber + " eşleşmiyor.");
                } else {
                    textViewResult.setText(selectedCity + " ile " + selectedNumber + " eşleşti!");
                }
            }
        });
    }
}