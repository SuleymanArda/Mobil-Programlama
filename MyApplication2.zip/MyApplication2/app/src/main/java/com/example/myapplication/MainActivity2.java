package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class MainActivity2 extends AppCompatActivity {

    private String[] citiesArray = {
            "Adana", "Adıyaman", "Afyonkarahisar", "Ağrı", "Amasya", "Ankara", "Antalya", "Artvin",
            "Aydın", "Balıkesir", "Bilecik", "Bingöl", "Bitlis", "Bolu", "Burdur", "Bursa",
            "Çanakkale", "Çankırı", "Çorum", "Denizli", "Diyarbakır", "Edirne", "Elazığ", "Erzincan",
            "Erzurum", "Eskişehir", "Gaziantep", "Giresun", "Gümüşhane", "Hakkari", "Hatay", "Isparta",
            "Mersin", "İstanbul", "İzmir", "Kars", "Kastamonu", "Kayseri", "Kırklareli", "Kırşehir",
            "Kocaeli", "Konya", "Kütahya", "Malatya", "Manisa", "Kahramanmaraş", "Mardin", "Muğla",
            "Muş", "Nevşehir", "Niğde", "Ordu", "Rize", "Sakarya", "Samsun", "Siirt",
            "Sinop", "Sivas", "Tekirdağ", "Tokat", "Trabzon", "Tunceli", "Şanlıurfa", "Uşak",
            "Van", "Yozgat", "Zonguldak", "Aksaray", "Bayburt", "Karaman", "Kırıkkale", "Batman",
            "Şırnak", "Bartın", "Ardahan", "Iğdır", "Yalova", "Karabük", "Kilis", "Osmaniye", "Düzce"
    };

    private List<String> cityList = new ArrayList<>();
    private List<Integer> numberList = new ArrayList<>();
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button buttonCheck = findViewById(R.id.buttonCheck);
        TextView textViewResult = findViewById(R.id.textViewResult);

        // Listeleri hazırla
        for (String city : citiesArray) {
            cityList.add(city);
        }

        for (int i = 1; i <= 81; i++) {
            numberList.add(i);
        }
        // Sayı listesini rastgele karıştırıyoruz (isteğe bağlı, ama kullanıcı rastgele sayılar yazacak demişti)
        Collections.shuffle(numberList);

        buttonCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Rastgele bir şehir seç
                int randomCityIndex = random.nextInt(cityList.size());
                String selectedCity = cityList.get(randomCityIndex);
                
                // Şehrin plakasını bul (Dizideki sırası + 1)
                // cityList'i karıştırmadığımız için citiesArray'deki index geçerli kalır.
                int plateNumber = randomCityIndex + 1;

                // Sayı listesinden rastgele bir sayı seç
                int randomNumberIndex = random.nextInt(numberList.size());
                int selectedNumber = numberList.get(randomNumberIndex);

                if (plateNumber != selectedNumber) {
                    textViewResult.setText(selectedCity + " ile " + selectedNumber + " eşleşmiyor.");
                } else {
                    textViewResult.setText(selectedCity + " ile " + selectedNumber + " eşleşti!");
                }
            }
        });
    }
}